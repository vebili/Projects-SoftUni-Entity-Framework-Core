﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public const string ConnectionString = @"Server=.;Database=MusicHub;Integrated Security=True;";
    }
}
