﻿namespace P01_HospitalDatabase.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=.;Database=Hospital;Integrated Security=True;";
    }
}