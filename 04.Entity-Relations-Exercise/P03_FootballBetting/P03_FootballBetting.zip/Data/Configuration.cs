﻿namespace P03_FootballBetting.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=.;Database=FootballBookmakerSystem;Integrated Security=True;";
    }
}