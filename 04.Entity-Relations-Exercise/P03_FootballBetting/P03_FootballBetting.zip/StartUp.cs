﻿namespace P03_FootballBetting
{
    using Data;
    public class StartUp
    {
        public static void Main(string[] args)
        {
            
        }
    }
}
